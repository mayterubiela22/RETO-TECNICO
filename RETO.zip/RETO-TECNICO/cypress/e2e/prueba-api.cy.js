describe('Pruebas de servicios REST - Signup y Login en Demoblaze', () => {
    const baseUrl = 'https://api.demoblaze.com';
    const usuarioNuevo = {
      username: 'nuevo_usuario_prueba'+ Date.now(), // Para evitar duplicados se agrega timestamp para validar varias ejecuciones
      password: 'clave_prueba'
    };
    const usuarioExistente = {
      username: 'usuario_mayte', // Usuario existente
      password: 'clave_mayte'
    };
  
    // Crear un nuevo usuario en https://api.demoblaze.com/signup 
    it('Crear un nuevo usuario en signup', () => {
        cy.request({  //Método para hacer solicitudes http
          method: 'POST',  //Método post para crear un usuario
          url: `${baseUrl}/signup`, //Completa la URL para signup
          headers: { //Arma el encabezado del request
            'Content-Type': 'application/json'  //Indica que los datos viajarán en formato json
          },
          body: {  //Arma el cuerpo del request o solicitud
            username: usuarioNuevo.username, //Nombre del usuario
            password: usuarioNuevo.password  //Clave del usuario
          }
        }).then((response) => {  //Después que ha recibido la respuesta al request
          // Verificar el código de estado HTTP
          expect(response.status).to.equal(200); // El código 200 indica que la solicitud fue exitosa
      
          // El body de la respuesta está vacío
          expect(response.body).to.be.empty; // Permite confirmar que el cuerpo de la respuesta está vacío
        });
      });

    // Intentar crear un usuario ya existente
    it('Intentar crear un usuario ya existente en signup', () => {
      cy.request({
        method: 'POST',
        url: `${baseUrl}/signup`, //Completa la URL para signup
        headers: {
          'Content-Type': 'application/json' //Indica que los datos viajarán en formato json
        },
        failOnStatusCode: false, //Permite que la prueba continúe, aunque la respuesta de la API sea un error.
        body: {
          username: usuarioExistente.username,
          password: usuarioExistente.password
        }
      }).then((response) => {
        expect(response.status).to.equal(200); // El código de respuesta que devuelve es 200
        expect(response.body).to.have.property('errorMessage').and.to.include('This user already exist.'); //Propiedad errorMessage indica la razón del fallo
      });
    });
  
    // Prueba para login con usuario y password correctos
    it('Login con usuario y password correctos', () => {
      cy.request({
        method: 'POST',
        url: `${baseUrl}/login`,
        headers: {
          'Content-Type': 'application/json' //Indica que los datos viajarán en formato json
        },
        body: {
          username: usuarioExistente.username,
          password: usuarioExistente.password
        }
      }).then((response) => {
        expect(response.status).to.equal(200);
        // Verificar que el body de la respuesta tiene un token
        expect(response.body).to.include('Auth_token'); // Valida el texto Auth_token en el body de la respuesta
      });
    });
  
    // Prueba para login con usuario y password incorrectos
    it('Login con usuario y password incorrectos', () => {
      cy.request({
        method: 'POST',
        url: `${baseUrl}/login`,
        headers: {
          'Content-Type': 'application/json'
        },
        failOnStatusCode: false, // No hacer que falle si la respuesta no es 2xx
        body: {
          username: 'usuario_incorrecto',
          password: 'clave_incorrecta'
        }
      }).then((response) => {
        expect(response.status).to.equal(200); // Debería respoder Código 401 para credenciales incorrectas
        expect(response.body).to.have.property('errorMessage').and.to.include('User does not exist.'); // Verificar mensaje de error
      });
    });
  });