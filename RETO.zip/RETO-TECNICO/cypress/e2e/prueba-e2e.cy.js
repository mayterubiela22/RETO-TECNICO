describe('Prueba E2E de un flujo de compras', () => {
  const usuario = 'standard_user';
  const clave = 'secret_sauce';
  //Antes de ejecutar cada prueba, visita la página https://www.saucedemo.com/
  beforeEach(() => {
    cy.visit('https://www.saucedemo.com/');
  });

  //Autenticación para ingreso a la página de compras
  it('Login', () => {
    cy.get('[data-test="username"]').type(usuario)
    cy.get('[data-test="password"]').type(clave)
    cy.get('#login-button').click()
    
    //Validar que se encuentre en la página de catálogo de productos
    cy.url().should('include','/inventory.html')
  })
  
  //Generar proceso de compra  
  it('Agregar productos', () => {
    
    //Login antes de agregar productos 
    cy.get('[data-test="username"]').type(usuario)
    cy.get('[data-test="password"]').type(clave)
    cy.get('#login-button').click()
    cy.url().should('include','/inventory.html')
    
    //Seleccionar y agregar el primer producto al carrito
    cy.get('#item_4_img_link > .inventory_item_img').click()
    cy.get('.btn_primary').click()
    cy.get('[data-test="shopping-cart-link"]').contains('1')
    
    //Regresar a la página de productos
    cy.get('.inventory_details_back_button').contains('Back')
    cy.go('back')
    
    //Seleccionar y agregar el segunto producto al carrito
    cy.get('#item_0_img_link > .inventory_item_img').click()
    cy.get('.btn_primary').click()
    
    //Verificar que se encuentren en el carrito dos productos
    cy.get('[data-test="shopping-cart-link"]').contains('2')
    cy.get('.inventory_details_back_button').contains('Back')
    
    //Abrir el contenido del carrito
    cy.get('[data-test="shopping-cart-badge"]').click()
    
    //Iniciar el checkout
    cy.get('[data-test="checkout"]').click()
    
    //Registrar datos para la factura
    cy.get('[data-test="firstName"]').type('Mayte')
    cy.get('[data-test="lastName"]').type('Guaman')
    cy.get('[data-test="postalCode"]').type('170204')
    cy.get('.btn_primary').click()
    cy.get(':nth-child(3) > .cart_item_label > .item_pricebar > [data-test="inventory-item-price"]')
    
    // Finalizar la compra
    cy.get('[data-test="finish"]').click();
    
    //Validar mensaje de confirmación de la compra
    cy.get('[data-test="complete-header"]').should('have.text', 'Thank you for your order!');
  })
})